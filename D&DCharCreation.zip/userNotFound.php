<html>
  <head>
    <title>D&D Character Generation User Not Found</title>
        </head>
        <body>
  	<body style="background-color:#FFCDA2">
      <style>
      body {
        background-image: url('forest7Bg.jpg');
        background-repeat:  no-repeat;
        text-shadow: 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 2px 2px 4px whitesmoke;
        color: whitesmoke;
        text-align: center;
      }
    </style>
<center>
<br><br>
<?php echo "<b>Error: user not found.</b><br><br>Hm... an adventurer with that username or password could not be found.<br>It is all too quiet to stay here for long. How would you like to proceed?" ?>


  <form method="post">
    <br>
        <a href="http://10.8.45.33/D&Dwebsite/returningUserSignIn.php"><input type="button" style="font-family: Times New Roman;border: 1px solid #000000;font-size: 20px;padding: 8px;border-radius: 3px;cursor: pointer;" name="backBtn" value="Return to Login"/></a></p>
          <br>
        <a href="http://10.8.45.33/D&Dwebsite/userStartPage.php"><input type="button" style="font-family: Times New Roman;border: 1px solid #000000;font-size: 20px;padding: 8px;border-radius: 3px;cursor: pointer;" name="returnBtn" value="Return to Homepage"/></a></p> 

        </center>
    </script> 
  </body>
</html>