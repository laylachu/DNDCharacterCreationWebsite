<html>
  <head>
    <title>D&D Character Generation</title>
  </head>
    <body>
    <style>
      body {
        background-image: url('forest6Bg.jpg');
        background-repeat:  no-repeat;
        text-shadow: 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black;
        color: whitesmoke;
        text-align: center;

      }
    </style>
      <center>
  <h1 style="font-size:60px;">Welcome to the world of Dungeons & Dragons!</h1>
  <!--Clearing and restarting session-->
  <?php session_start(); ?>
  <?php session_destroy(); ?>
  <?php session_start(); ?>
 <h1>How would you like to proceed?</h1>
 <br>
      <form method="post">
                <!--New character redirect-->
      <a href="http://10.8.45.33/D&Dwebsite/D&DCharacterCreation.php?generationBtn=Generate"><input type="button" value="Create a new character" style="font-family: Times New Roman;font-size: 30px;border: 1px solid #000000;padding: 8px;border-radius: 3px;cursor: pointer;"/></a></p>
      <br>
                <!--Existing character redirect-->
        <a href="http://10.8.45.33/D&Dwebsite/returningUserSignIn.php"><input type="button" value="View an existing character" style="font-family: Times New Roman;font-size: 30px;border: 1px solid #000000;padding: 8px;border-radius: 3px;cursor: pointer;"/></a></p>
        <br>
        <a href="https://www.dndwiki.io/" style="text-shadow: 0px 0px 4px whitesmoke, 0px 0px 4px whitesmoke, 0px 0px 4px whitesmoke, 0px 0px 4px whitesmoke;">Visit dndwiki.io to learn more about D&D before you begin your journey!</a>
        <br>
    </center>
  </body>
</html>