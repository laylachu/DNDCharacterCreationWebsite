
<html>
  <head>
    <title>D&D Character Generation</title>
    </head>
    <body>
    <style>
      body {
        background-image: url('forest2Bg.jpg');
        background-repeat:  no-repeat;
        text-shadow: 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black;
        color: whitesmoke;
        text-align: center;
      }
    </style>
  	<body style="background-color:#FFCDA2">
    <center>
    <h1 style="font-size:60px;">Welcome back!</h1>

<?php

session_start();

$conn = mysqli_connect("localhost","root","newpass","layladb");

?>

	<h1>Sign in below to access your character details:</h1>
    <form form action="loginDb.php" method="post">
    <?php echo '<p>Enter username: </p>'; ?>
        <input type="text" style="border-radius: 3px;" name="returningUn" required/>
    <?php echo '<p>Enter password: </p>'; ?>
        <input type="password" style="border-radius: 3px;" name="returningPw" required/>
    <br>
    <br>
        
        <!--Button click checks if input is in the database-->
	<input type="submit" name="loginBtn" class="button" value="Login" style="font-family: Times New Roman;border: 1px solid #000000;padding: 8px;border-radius: 3px;cursor: pointer;"/> </form>

<?php

        if (isset($_POST['loginBtn'])) {
            header("Location: http://10.8.45.33/D&Dwebsite/userCharInfo.php");
        }

?>

	<a href="http://10.8.45.33/D&Dwebsite/userStartPage.php"><input type="button" name="returnBtn" value="Back"style="font-family: Times New Roman;border: 1px solid #000000;padding: 8px;border-radius: 3px;cursor: pointer;"/></a></p>
    </center>
  </body>
</html>