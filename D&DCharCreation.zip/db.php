<form method="REQUEST">
<?php
session_start();

  //print_r($_POST); //returning an array

  if(isset($_POST['usernameTxt'])){
    $usernameDnd = $_REQUEST['usernameTxt'];
    $passwordDnd = $_REQUEST['passwordTxt'];
    $characterData = json_decode($_REQUEST['characterData'], TRUE);
    $abilitiesData = json_decode($_REQUEST['abilitiesData'], TRUE);

    //$_SESSION['userNew'] = $usernameDnd;
    //$_SESSION['character'] = $characterData;
    //$_SESSION['abilities'] = $abilitiesData;

$servername = "localhost";
$username = "root";
$password = "newpass";
$dbname = "layladb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

echo "Connected successfully";

//inserting user information into database
$sqlquery = ("INSERT INTO users (username, password, race, class, background, alignment, strength, dexterity, constitution, intelligence, wisdom, charisma) VALUES ('$usernameDnd', '$passwordDnd', '".$characterData['race']."', '".$characterData['class']."', '".$characterData['bkgd']."', '".$characterData['align']."', '".$abilitiesData['strength']."', '".$abilitiesData['dexterity']."', '".$abilitiesData['constitution']."', '".$abilitiesData['intelligence']."', '".$abilitiesData['wisdom']."', '".$abilitiesData['charisma']."')");

  //able to insert into database
  if(mysqli_query($conn, $sqlquery)) {
    //adds user data to session variable
    $query = 'SELECT * FROM users WHERE username="' . $usernameDnd . '" AND password="' . $passwordDnd . '"';
    $check = mysqli_query($conn, $query);
    $_SESSION['user'] = mysqli_fetch_assoc($check);

    echo "Successful.";
    header("Location: http://10.8.45.33/D&Dwebsite/userCharInfo.php");
  }
  else {
    echo "ERROR: Sorry, $sql. "
    . mysqli_error($conn);
  }


  if ($result->num_rows > 0) {
  // output data of each rw
    while($row = $result->fetch_assoc()) {
      echo "id: " . $row["id"]. " - Name: " . $row["username"]. " " . $row["password"]. "<br>";
      }
    }   
    else {
      echo "0 results";
    }
  }
?>