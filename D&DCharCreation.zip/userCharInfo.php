<html>
  <head>
    <title>D&D Character Generation</title>
    </head>
    <body style="background-color:#FFCDA2">
    <style>
      body {
        background-image: url('forest5Bg.jpg');
        background-repeat:  no-repeat;
        text-shadow: 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 2px 2px 4px whitesmoke;
        color: whitesmoke;
        text-align: center;
      }
    </style>
    <h4>D&D Character Creation</h4>
    <center>
    <h1>My Characters</h1>
    <?php 
        session_start();
        $user = $_SESSION['user'];
        $conn = mysqli_connect("localhost","root","newpass","layladb");
        $query = 'SELECT username, race, class, background, alignment, strength, dexterity, constitution, intelligence, wisdom, charisma FROM users WHERE username="' .  $user['username'] .  '" AND password="' . $user['password']  . '"';
        $result = mysqli_query($conn, $query);
        //$row = mysqli_fetch_assoc($result);
    ?>
        
        <table cellspacing="30" bgcolor="#013220" border="3"> 
            <thead>
                <tr bgcolor="#0B6142">
                <th>Username</th> <th>Race</th> <th>Class</th> <th>Background</th> <th>Alignment</th> <th>Strength</th> <th>Dexterity</th> <th>Constitution</th> <th>Intelligence</th> <th>Wisdom</th> <th>Charisma</th>
            </thead>
                <tbody>
                <?php
                    while ($row = mysqli_fetch_row($result)) {
                    echo "<tr>";
                        foreach($row as $c){
                            echo "<td>" . $c . "</td>";
                        }
                    echo "</tr>";
                    }
                ?>
                </tbody>
            </table>

<!---DESCRIPTIONS PRINTED BASED ON WHAT IS IN THE TABLE FOR THE USERNAME AND PASSWORD SPECIFIED--->

<?php
//RACE DESCRIPTION
        if ($user['race'] == "Dragonborne"){
            echo "<p><b>Dragonborne</b> <br>Descendants of dragons, these draconic humanoids live in clans who they value more than their life itself. <br>Depending on their color, they get a breath attack of a specific type, as well as resistance to that <br>same type of damage in combat. They tend to be as strong as they are charismatic, <br>just like their fellow ancestors. Even though they are covered in scales, they lack the tail and wings that <br>make dragons so characteristic.
                <br><br> <b>Languages:</b> You can speak, read, and write Common and Draconic. Draconic is thought to be one of the oldest languages and is often used in the study of magic. <br>The language sounds harsh to most other creatures and includes numerous hard consonants and sibilants.<p>";
        }
        else if ($user['race'] == "Halfling"){
          echo "<p><b>Halfling</b> <br>Halflings are isolated, cheerful people who love the commodity of their homes and communities. <br>That’s the main reason most of them don’t abandon their birthplaces (shires). <br>However, a strong sense of curiosity inhabits in most of them, leading these little folk to become adventurers or travel to <br>other places. They are extremely agile, but as a result of their short legs, not as fast as the other races.<br><br> <b>Languages:</b> You can speak, read, and write Common and Halfling. The Halfling language isn't secret, but halflings are loath to share it with others. <br>They write very little, so they don't have a rich body of literature. Their oral tradition, however, is very strong. Almost all halflings speak Common to <br>converse with the people in whose lands they dwell or through which they are traveling.<p>";
        }
        else if ($user['race'] == "Dwarf"){
          echo "<p><b>Dwarf</b> <br>Stout, short and hardworking. Those might be the best words to describe a dwarf. <br>Having their race forged by the god Moradin, they were taught of the benefits of hard labor, perfection in their works, <br>and the importance of their clans. Dwarves live their long lives with a spirit of good and justice, <br>that may only be corrupted by greed. Their sturdiness allows them to be more resistant than other classes <br>in combat as well as resist poison.
            <br><br> <b>Languages:</b>  You can speak, read, and write Common and Dwarvish. <p>";
        }
        else if ($user['race'] == "Elf"){
          echo "<p><b>Elf</b> <br>Elves are magical and gracious beings, as well as very close to being eternal. They develop many different attitudes during their life. <br>When young (young being up to 100 years old) they have an adventurous and curious way of thought, making them go for adventures. By the time they <br>reach adulthood their personalities change and become much more peaceful, but don’t discard the idea of going exploring until they become elders. They make <br>for excellent artists and tend to be quite chaotic when it comes to laws. Last but not least, they don’t sleep but enter trances for 4 hours a <br>day in which they remain semiconscious.
            <br><br> <b>Languages:</b> You can speak, read, and write Common and Elvish. Elvish is fluid, with subtle intonations and intricate grammar. Elven literature is rich and varied, and their songs and poems are <br>famous among other races. Many bards learn their language so they can add Elvish ballads to their repertoires.
            <br><br> <b>Languages:</b> <p>";
        }
        else if ($user['race'] == "Human"){
          echo "<p><b>Human</b> <br>Well… I suppose you are a human, so you should know what we are good at. Absolutely nothing! <br>Or more precisely, a bit in everything. Humans are quite more anxious and eager <br>to adventure than the other races due to their short lives (in comparison with the others).
          <br><br> <b>Languages:</b> You can speak, read, and write Common and one extra language of your choice. Humans typically learn the languages of other peoples they deal with, including obscure dialects. <br>They are fond of sprinkling their speech with words borrowed from other tongues: Orc curses, Elvish musical expressions, <br>Dwarvish military phrases, and so on. <p>";
        }
        else if ($user['race'] == "Gnome"){
          echo "<p><b>Gnome</b> <br>Gnomes are weird super positive beings. Their spirits shine even in the darkest nights. Great inventors, pranksters, and even better intellectuals. <br>Living away from other communities they tend to live pretty normal lives in their about 500 years. However, just like halflings, curiosity <br>is something that every one of them carries, as well as their impulsive behavior, creating excellent and many adventurers out of them.
          <br><br> <b>Languages:</b> None <p>";
        }
        else if ($user['race'] == "Half-Elf"){
          echo "<p><b>Half-Elf</b> <br>These beings combine the best parts of elves and humans, or so they say. They don’t really belong in either of both worlds, <br>having to decide the community they find themselves more identified with. That’s the reason why <br>they work excellently as ambassadors or wander off feeling excluded from all places, <br>sometimes in the search for weird adventurers with whom they can find a sense of belonging.
          <br><br> <b>Languages:</b>  You can speak, read, and write Common, Elvish, and one extra language of your choice.<p>";
        }
        else if ($user['race'] == "Half-Orc"){
          echo "<p><b>Half-Orc</b> <br>Half orcs have orc blood running through their veins. This makes them much stronger than normal people, as well as hardy. <br>However, that also can make them act impulsively and savagely. They often live, or at least <br>used to in orc tribes and may or may not feel the rage of Gruumsh within them (Gruumsh being the orc god). <br>While many of them triumph as leaders in their tribe due to their high IQ in comparison with the others, others are exiled and go in <br>search of jobs in communities or go adventuring. Their high endurance makes them almost impossible to fall in combat.
          <br><br> <b>Languages:</b>  You can speak, read, and write Common and Orc. Orc is a harsh, grating language with hard consonants. It has no script of its own but is written in the Dwarvish script.<p>";
        }
        else if ($user['race'] == "Tiefling"){
          echo "<p><b>Tiefling</b> <br>Tieflings take lots of forms and colors. They can have different kinds of horns and tails, as well as be from a great variety of colors. <br>Nevertheless, they share some kind of curse. These are beings of infernal lineage due to a pact that someone in the long past made with Asmodeus (lord of Hell). <br>They look mostly human, not taking into account the features described above. Even though they are mostly intellectual and <br>highly charismatic beings, they tend to be received with mistrust by superstitious people.
          <br><br> <b>Languages:</b> You can speak, read, and write Common and Infernal.<p>";
        }

//CLASS DESCRIPTION
        if ($user['class'] == "Barbarian"){
            echo "<p><b>Barbarian</b> <br>A fierce warrior of primitive background who can enter a battle rage.<p>";
        }
        else if ($user['class'] == "Bard"){
            echo "<p><b>Bard</b> <br>An inspiring magician whose power echoes the music of creation.<p>";
        }
        else if ($user['class'] == "Cleric"){
            echo "<p><b>Cleric</b> <br>A priestly champion who wields divine magic in service of a higher power.<p>";
        }
        else if ($user['class'] == "Druid"){
            echo "<p><b>Druid</b> <br>A priest of the Old Faith, wielding the powers of nature — moonlight and plant growth, fire and lightning — and adopting animal forms.<p>";
        }
        else if ($user['class'] == "Fighter"){
            echo "<p><b>Fighter</b> <br>A master of martial combat, skilled with a variety of weapons and armor.<p>";
        }
        else if ($user['class'] == "Monk"){
            echo "<p><b>Monk</b> <br>A master of martial arts, harnessing the power of the body in pursuit of physical and spiritual perfection.<p>";
        }
        else if ($user['class'] == "Paladin"){
            echo "<p><b>Paladin</b> <br>A holy warrior bound to a sacred oath.<p>";
        }
        else if ($user['class'] == "Ranger"){
            echo "<p><b>Ranger</b> <br>A warrior who uses martial prowess and nature magic to combat threats on the edges of civilization.<p>";
        }
        else if ($user['class'] == "Rogue"){
            echo "<p><b>Rogue</b> <br>A scoundrel who uses stealth and trickery to overcome obstacles and enemies.<p>";
        }
        else if ($user['class'] == "Sorcerer"){
            echo "<p><b>Sorcerer</b> <br>A spellcaster who draws on inherent magic from a gift or bloodline.<p>";
        }
        else if ($user['class'] == "Warlock"){
            echo "<p><b>Warlock</b> <br>A wielder of magic that is derived from a bargain with an extraplanar entity.<p>";
        }
        else if ($user['class'] == "Wizard"){
            echo "<p><b>Wizard</b> <br>A scholarly magic-user capable of manipulating the structures of reality.<p>";
        }

//BACKGROUND DESCRIPTION

        if ($user['background'] == "Acolyte"){
            echo "<p><b>Acolyte</b> <br>You have spent your life in the service of a temple to a specific god or pantheon of gods. You act as an intermediary between the realm of the holy and the mortal world, <br>performing sacred rites and offering sacrifices in order to conduct worshipers into the presence of the divine. <br>You are not necessarily a cleric—performing sacred rites is not the same thing as channeling divine power. <br><br>
                <b>Feature: Shelter of the Faithful</b><br>
                As an acolyte, you command the respect of those who share your faith, and you can perform the religious ceremonies of your deity. You and your adventuring companions can <br>expect to receive free healing and care at a temple, shrine, or other established presence of your faith, <br>though you must provide any material components needed for spells. Those who share your religion will support you (but only you) at a modest lifestyle.
                <br><br>Skill Proficiencies: Insight, Religion || Additional Languages: Two of your choice || Tool Proficiencies: None<br>
                Equipment: A holy symbol (a gift to you when you entered the priesthood), a prayer book or prayer wheel, 5 sticks of incense, vestments, a set of common clothes, and a belt pouch containing 15 gp<p>";
        }

        else if ($user['background'] == "Charlatan"){
            echo "<p><b>Charlatan</b> <br>You have always had a way with people. You know what makes them tick, you can tease out their hearts' desires after <br>a few minutes of conversation, and with a few leading questions you can read them like they were children's books. It's a useful talent, <br>and one that you're perfectly willing to use for your advantage.<br><br>
                <b>Feature: False Identity</b><br>
                You have created a second identity that includes documentation, established acquaintances, and disguises that allow you to assume that persona. <br>Additionally, you can forge documents including official papers and personal letters, as long as you have seen an <br>example of the kind of document or the handwriting you are trying to copy.
                <br><br> Skill Proficiencies: Deception, Sleight of Hand || Additional Languages: None || Tool Proficiencies: Disguise kit, Forgery kit<br>
                Equipment: A set of fine clothes, a disguise kit, tools of the con of your choice (ten stoppered bottles filled with colored liquid, a set of weighted dice, a deck of marked cards, or <br>a signet ring of an imaginary duke), and a belt pouch containing 15 gp<p>";
        }

        else if ($user['background'] == "Criminal"){
            echo "<p><b>Criminal</b> <br>You are an experienced criminal with a history of breaking the law. You have spent a lot of time among other criminals and still have contacts within <br>the criminal underworld. You’re far closer than most people to the world of murder, theft, and violence that pervades the <br>underbelly of civilization, and you have survived up to this point by flouting the rules and regulations of society.<br><br>
                <b>Feature: Criminal Contact</b><br> You have a reliable and trustworthy contact who acts as your liaison to a network of other criminals. You know how to get messages to and from your contact, <br>even over great distances; specifically, you know the local messengers, corrupt caravan masters, and seedy sailors who can deliver messages for you.<br><br>
                    Skill Proficiencies: Deception, Stealth || Additional Languages: None || Tool Proficiencies: One type of gaming set, thieves’ tools<br>
                    Equipment: A crowbar, a set of dark common clothes including a hood, and a pouch containing 15 gp<p>";
        }

        else if($user['background'] == "Entertainer"){
            echo "<p><b>Entertainer</b> <br>You thrive in front of an audience. You know how to entrance them, entertain them, and even inspire them. Your poetics can stir the hearts of those who hear you, <br>awakening grief or joy, laughter or anger. Your music raises their spirits or captures their sorrow. Your dance steps captivate, your humor cuts to the quick. <br>Whatever techniques you use, your art is your life. <br><br>
            <b>Feature: By Popular Demand</b> <br>You can always find a place to perform, usually in an inn or tavern but possibly with a circus, at a theater, or even in a noble's court. At such a place, you receive free <br>lodging and food of a modest or comfortable standard (depending on the quality of the establishment), as long as you perform each night. In addition, your performance makes you <br>something of a local figure. When strangers recognize you in a town where you have performed, they typically take a liking to you.<Br><br>
                Skill Proficiencies: Acrobatics, Performance || Additional Languages: None || Tool Proficiencies: Disguise kit, one type of musical instrument<br>
                Equipment: A musical instrument (one of your choice), the favor of an admirer (love letter, lock of hair, or trinket), costume clothes, and a belt pouch containing 15 gp<p>";
        }

        else if($user['background'] == "Folk-Hero"){
            echo "<p><b>Folk-Hero</b> <br>You come from a humble social rank, but you are destined for so much more. Already the people of your home village regard you as their champion, <br>and your destiny calls you to stand against the tyrants and monsters that threaten the common folk everywhere.<br><br> 
                <b>Feature: Rustic Hospitality</b> <br> Since you come from the ranks of the common folk, you fit in among them with ease. You can find a place to hide, rest, or recuperate among other commoners, unless you have shown yourself to be a <br>danger to them. They will shield you from the law or anyone else searching for you, though they will not risk their lives for you.
                <br><br>Skill Proficiencies: Animal Handling, Survival || Additional Languages: None || Tool Proficiencies: One type of artisan's tools, vehicles (land) <br>
                Equipment: A set of artisan's tools (one of your choice), a shovel, an iron pot, a set of common clothes, and a belt pouch containing 10 gp<p>";
        }

        else if($user['background'] == "Guild Artisan"){
            echo "<p><b>Guild Artisan</b> <br>You are a member of an artisan's guild, skilled in a particular field and closely associated with other artisans. You are a well-established part of the mercantile world, <br>freed by talent and wealth from the constraints of a feudal social order. You learned your skills as an apprentice to a master artisan, <br>under the sponsorship of your guild, until you became a master in your own right.
            <br><br> <b>Feature: Guild Membership</b> <br> As an established and respected member of a guild, you can rely on certain benefits that membership provides. Your fellow guild members will provide you with lodging and food if necessary, <br>and pay for your funeral if needed. In some cities and towns, a guildhall offers a central place to meet other members of your profession, which can be a good place to meet potential patrons, <br>allies, or hirelings. Guilds often wield tremendous political power. <br>If you are accused of a crime, your guild will support you if a good case can be made for your innocence or the crime is justifiable. You can also gain access to powerful political figures through the guild, <br>if you are a member in good standing. Such connections might require the donation of money or magic items to the guild's coffers. <br><b>You must pay dues of 5 gp per month to the guild. If you miss payments, you must make up back dues to remain in the guild's good graces.</b>
            <br><br> Skill Proficiencies: Insight, Persuasion || Additional Languages: One of your choice || Tool Proficiencies: One type of artisan's tools <br>
            Equipment: A set of artisan's tools (one of your choice), a letter of introduction from your guild, a set of traveler's clothes, and a belt pouch containing 15 gp<p>";
        }

        else if($user['background'] == "Hermit"){
            echo "<p><b>Hermit</b> <br>You lived in seclusion – either in a sheltered community such as a monastery, or entirely alone – for a formative part of your life. <br>In your time apart from the clamor of society, you found quiet, solitude, and perhaps some of the answers you were looking for.<br><br><b>Feature: Discovery</b><br> The quiet seclusion of your extended hermitage gave you access to a unique and powerful discovery. The exact nature of this revelation depends on the nature of your seclusion. <br>It might be a great truth about the cosmos, the deities, the powerful beings of the outer planes, or the forces of nature. It could be a site that no one else has ever seen. You might have uncovered a fact that has long been forgotten, <br>or unearthed some relic of the past that could rewrite history. It might be information that would be damaging to the people who or consigned you to exile, and hence the reason for your return to society. <br><br>
                Skill Proficiencies: Medicine, Religion || Additional Languages: One of your choice || Tool Proficiencies: Herbalism kit<br>
                Equipment: A scroll case stuffed full of notes from your studies or prayers, a winter blanket, a set of common clothes, an herbalism kit, and 5 gp<p>";
        }

        else if($user['background'] == "Noble"){
            echo "<p><b>Noble</b> <br>You understand wealth, power, and privilege. You carry a noble title, and your family owns land, collects taxes, and wields significant political influence. <br>You might be a pampered aristocrat unfamiliar with work or discomfort, a former merchant just elevated to the nobility, or a disinherited scoundrel with a <br>disproportionate sense of entitlement. Or you could be an honest, hard-working landowner who cares deeply about the people who live and work on your land, <br>keenly aware of your responsibility to them. <br><br><b>Feature: Position of Privilege</b><br>Thanks to your noble birth, people are inclined to think the best of you. You are welcome in high society, and people assume you have the right to be wherever you are. <br>The common folk make every effort to accommodate you and avoid your displeasure, and other people of high birth treat you as a member of the same social sphere. <br>You can secure an audience with a local noble if you need to.<br><br>
                Skill Proficiencies: History, Persuasion || Additional Languages: One of your choice || Tool Proficiencies: One type of gaming set<br>
                Equipment: A set of fine clothes, a signet ring, a scroll of pedigree, and a purse containing 25 gp<p>";
        }

        else if($user['background'] == "Outlander"){
            echo "<p><b>Outlander</b> <br>You grew up in the wilds, far from civilization and the comforts of town and technology. You've witnessed the migration of herds larger than forests, survived weather more extreme <br>than any city-dweller could comprehend, and enjoyed the solitude of being the only thinking creature for miles in any direction. <br>The wilds are in your blood, whether you were a nomad, an explorer, a recluse, a hunter-gatherer, or even a marauder. Even in places where you don't know the specific features of the terrain, <br>you know the ways of the wild.<br><br>
                <b>Feature: Wanderer</b><br>You have an excellent memory for maps and geography, and you can always recall the general layout of terrain, settlements, and other features around you. <br>In addition, you can find food and fresh water for yourself and up to five other people each day, provided that the land <br>offers berries, small game, water, and so forth. <br><br>
                Skill Proficiencies: Athletics, Survival || Additional Languages: One of your choice || Tool Proficiencies: One type of musical instrument <br>
                Equipment: A staff, a hunting trap, a trophy from an animal you killed, a set of traveler's clothes, and a belt pouch containing 10 gp<p>";
        }

        else if($user['background'] == "Sage"){
            echo "<p><b>Sage</b> <br>You spent years learning the lore of the multiverse. You scoured manuscripts, studied scrolls, and listened to the greatest experts <br>on the subjects that interest you. Your efforts have made you a master in your fields of study. <br><br>
            <b>Feature: Researcher</b> <br>When you attempt to learn or recall a piece of lore, if you do not know that information, you often know where and from whom you can obtain it. <br>Usually, this information comes from a library, scriptorium, university, or a sage or other learned person or creature, Your DM might rule that the knowledge you seek is <br>secreted away in an almost inaccessible place, or that it simply cannot be found. Unearthing the deepest secrets of the multiverse <br>can require an adventure or even a whole campaign.<br><br>
            Skill Proficiencies: Arcana, History || Additional Languages: None || Tool Proficiencies: Two of your choice <br>
            Equipment: A bottle of black ink, a quill, a small knife, a letter from a dead colleague posing a question you have not yet been able to answer, a set of common clothes, and a belt pouch containing 10 gp<p>";
        }

        else if($user['background'] == "Sailor"){
            echo "<p><b>Sailor</b> <br>You sailed on a seagoing vessel for years. In that time, you faced down mighty storms, monsters of the deep, and those who wanted to sink your craft to the bottomless depths. <br>Your first love is the distant line of the horizon, but the time has come to try your hand at something new.<br><br>
            <b>Feature: Ship's Passage</b> <br>When you need to, you can secure free passage on a sailing ship for yourself and your adventuring companions. You might sail on the ship you served on, or another ship you have good relations with (perhaps one captained by a former crewmate). <br>Because you're calling in a favor, you can't be certain of a schedule or route that will meet your every need. Your Dungeon Master will determine how long it takes to get where you need to go. In return for your free passage, <br>you and your companions are expected to assist the crew during the voyage.<br><br>
            Skill Proficiencies: Athletics, Perception || Additional Languages: None || Tool Proficiencies: Navigator's tools, vehicles (water) <br>
            Equipment: A belaying pin (club), silk rope (50 feet), a lucky charm such as a rabbit foot or a small stone with a hole in the center (or you may roll for a random trinket on the Trinkets table in chapter 5), <br>a set of common clothes, and a belt pouch containing 10 gp<p>";
        }

        else if($user['background'] == "Soldier"){
            echo "<p><b>Soldier</b> <br>War has been your life for as long as you care to remember. You trained as a youth, studied the use of weapons and armor, learned basic survival techniques, <br>including how to stay alive on the battlefield. You might have been part of a standing national army or a mercenary company, or perhaps a <br>member of a local militia who rose to prominence during a recent war.<br><br>
            <b>Feature: Military Rank</b> <br>You have a military rank from your career as a soldier. Soldiers loyal to your former military organization still recognize your authority and influence, and they defer to you <br>if they are of a lower rank. You can invoke your rank to exert influence over other soldiers and requisition simple equipment or horses for temporary use. You can also usually gain access to friendly military <br>encampments and fortresses where your rank is recognized.<br><br>
            Skill Proficiencies: Athletics, Intimidation || Additional Languages: None || Tool Proficiencies: One type of gaming set, vehicles (land)<br>
            Equipment: An insignia of rank, a trophy taken from a fallen enemy (a dagger, broken blade, or piece of a banner), a bone dice set or playing card set, <br>a set of common clothes, and a belt pouch containing 10 gp<p>";
        }

        else if($user['background'] == "Urchin"){
            echo "<p><b>Urchin</b> <br>You grew up on the streets alone, orphaned, and poor, You had no one to watch over you or to provide for you, so you learned to provide for yourself. You fought fiercely over food <br>and kept a constant watch out for other desperate souls who might steal from you. You slept on rooftops and in alleyways, exposed to the elements, <br>and endured sickness without the advantage of medicine or a place to recuperate. You've survived despite all odds, and did so through cunning, strength, speed, <br>or some combination of each.<br><br>
            <b>Feature: City Secrets</b> <br>You know the secret patterns and flow to cities and can find passages through the urban sprawl that others would miss. When you are not in combat, you (and companions you lead) <br>can travel between any two locations in the city twice as fast as your speed would normally allow. <br><br>
            Skill Proficiencies: Sleight of Hand, Stealth || Additional Languages: None || Tool Proficiencies: Disguise kit, Thieves' tools <br>
            Equipment: A small knife, a map of the city you grew up in, a pet mouse, a token to remember your parents by, a set of common clothes, and a belt pouch containing 10 gp<p>";
        
        }

//ALIGNMENT DESCRIPTIONS
        if ($user['alignment'] == "Lawful Good"){
            echo "<p><b>Lawful Good</b> creatures can be counted on to do the right thing as expected by society.<p>";
        }

        else if ($user['alignment'] == "Neutral Good"){
            echo "<p><b>Neutral Good</b> folk do the best they can to help others according to their needs.<p>";
        }

        else if ($user['alignment'] == "Chaotic Good"){
            echo "<p><b>Neutral Good</b> creatures act as their conscience directs, with little regard for what others expect.<p>";
        }

        else if ($user['alignment'] == "Lawful Neutral"){
            echo "<p><b>Lawful Neutral</b> individuals act in accordance with law, tradition, or personal codes.<p>";
        }

        else if ($user['alignment'] == "True Neutral"){
            echo "<p><b>True Neutral</b> is the alignment of those who prefer to steer clear of moral questions and don’t take sides, doing what seems best at the time.<p>";
        }

        else if ($user['alignment'] == "Chaotic Neutral"){
            echo "<p><b>Chaotic Neutral</b> creatures methodically take what they want, within the limits of a code of tradition, loyalty, or order.<p>";
        }

        else if ($user['alignment'] == "Lawful Evil"){
            echo "<p><b>Lawful Evil</b> creatures follow their whims, holding their personal freedom above all else.<p>";
        }
        
        else if ($user['alignment'] == "Neutral Evil"){
            echo "<p><b>Neutral Evil</b> is the alignment of those who do whatever they can get away with, without compassion or qualms.<p>";
        }

        else if ($user['alignment'] == "Chaotic Evil"){
            echo "<p><b>Chaotic Evil</b> creatures act with arbitrary violence, spurred by their greed, hatred, or bloodlust.<p>";
        }

?>
        <a href="https://www.dndwiki.io/" style="text-shadow: 0px 0px 4px lavenderblush, 0px 0px 4px lavenderblush, 0px 0px 4px lavenderblush, 0px 0px 4px lavenderblush;">Visit dndwiki.io for even more information!</a>
        <br>
        <br>
        <a href="http://10.8.45.33/D&Dwebsite/userStartPage.php"><input type="button" name="exitBtn" value="Exit"style="font-family: Times New Roman;border: 1px solid #000000;padding: 8px;border-radius: 3px;cursor: pointer;"/></a></p>
        <br>
        <br>
        <br>
    </center>
    <script> 
    </script> 
  </body>
</html>"