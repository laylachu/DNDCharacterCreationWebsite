<html>
  <head>
    <title>D&D Character Generation User Not Found</title>
        </head>
        <body>
  	<body style="background-color:#FFCDA2">
<center>
<br><br>

<h2>Error: must enter username and password.</h2>
<h4>Return back to try again.</h4>

<a href="http://10.8.45.33/D&DCharacterCreation.php"><input type="button" name="returnBtn" value="Back"/></a></p>

        </center>
    </script> 
  </body>
</html>