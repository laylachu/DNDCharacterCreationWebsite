<?php

  //logs in user
  if(isset($_POST['returningUn'])) {
      $returningUser = $_REQUEST['returningUn'];
      $returningPass = $_REQUEST['returningPw'];
  
  $conn = mysqli_connect("localhost","root","newpass","layladb");

  //checks to see if username and password are both present in database, both have to be there for login to work and have to be same row
  $query = 'SELECT * FROM users WHERE username="' . $returningUser . '" AND password="' . $returningPass . '"';
  $check = mysqli_query($conn, $query);
   
  //if user is in database
      if (mysqli_num_rows($check) > 0) {

        //$row = mysqli_fetch_assoc($char);
        session_start();
        $_SESSION['user'] = mysqli_fetch_assoc($check);

        //redirection
        header("Location: http://10.8.45.33/userCharInfo.php");
      }

      //user not found page has redirect back to login
    else {
          header("Location: http://10.8.45.33/userNotFound.php");
      }
  }
?>

