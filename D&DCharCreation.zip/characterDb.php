<?php/*
if(isset($_POST['returningUn'])){
    $returningUser = $_REQUEST['returningUn'];
    $returningPass = $_REQUEST['returningPw'];


// Create connection
$conn = mysqli_connect("localhost","root","newpass","layladb");

// Check connection
if ($conn->connect_error) {

  die("Connection failed: " . $conn->connect_error);

}

echo "Connected successfully";
//inserting username and password into database
//get username from form
$select = mysqli_query($conn, "SELECT * FROM users WHERE username = '".$_POST['returningUser']."'");
if(mysqli_num_rows($select)) {
    header("Location: http://10.8.45.33/userCharInfo.php");
}
else {
header("Location: http://10.8.45.33/userNotFound.php");
}

  if ($result->num_rows > 0) {

  // output data of each rw
    while($row = $result->fetch_assoc()) {
      echo "id: " . $row["id"]. " - Name: " . $row["username"]. " " . $row["password"]. "<br>";
    }
  }   
    else {
      echo "0 results";
  }
}*/
?>
