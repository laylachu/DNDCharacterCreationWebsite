<html>
  <head>
    <title>D&D Character Generation</title>
    </head>
    <style>
        body {
            background-image: url('forestBg.jpg');
            text-shadow: 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black, 0px 0px 4px black;
            color: whitesmoke;
        }
    </style>
    <body>
  	<body style="background-color:#FFCDA2">
    <center>
    <h1>Welcome to the world of D&D!</h1>
<?php
session_start();
$conn = mysqli_connect("localhost","root","newpass","layladb");
//Arrays for button choices and randomization on click
//Race
$raceArr = array("Dwarf", "Elf", "Halfling", "Human", "Dragonborne", "Gnome", "Half-Elf", "Half-Orc", "Tiefling");
$keyOne = shuffle($raceArr);

//Class
$classArr = array("Barbarian", "Bard", "Cleric", "Druid", "Fighter", "Monk", "Paladin", "Ranger", "Rogue", "Sorcerer", "Warlock", "Wizard");
$keyTwo = shuffle($classArr);

//Background
$backgroundArr = array("Acolyte", "Charlatan", "Criminal", "Entertainer", "Folk-Hero", "Guild Artisan", "Hermit", "Noble", "Outlander", "Sage", "Sailor", "Soldier", "Urchin");
$keyThree = shuffle($backgroundArr);

//Alignment
$alignmentArr = array("Lawful Good", "Neutral Good", "Chaotic Good", "Lawful Neutral", "True Neutral", "Chaotic Neutral", "Lawful Evil", "Neutral Evil", "Chaotic Evil");
$keyFour = shuffle($alignmentArr);

//Shuffling for value of each ability
$abNumArr = array("15 (+2 modifier)", "14 (+2 modifier)", "13 (+1 modifier)", "12 (+1 modifier)", "10 (No modifier)", "8 (-1 modifier)");
//shuffle($abNumArr);
?>
<!--Button initialization-->
    <?php echo '<p>To start, begin by generating your character by clicking the Generate button.</p>'; ?>
    <form method="post">
    <input type="submit" name="generationBtn" class="button" value="Generate!" style="font-family: Times New Roman;border: 1px solid #000000;padding: 8px;border-radius: 3px;cursor: pointer;"/> </form>

<?php
//all variables for json encoding
$randomizedRace = $raceArr[$keyOne];
$randomizedClass = $classArr[$keyTwo];
$randomizedBkgd = $backgroundArr[$keyThree];
$randomizedAlign = $alignmentArr[$keyFour];

//abilities shuffled
$abilitiesCount = shuffle($abNumArr);
$strength = $abNumArr[0];
$dexterity = $abNumArr[1];
$constitution = $abNumArr[2];
$intelligence = $abNumArr[3];
$wisdom = $abNumArr[4];
$charisma = $abNumArr[5];

//for character details and abilities
$character = array('race'=>$randomizedRace,'class'=>$randomizedClass,'bkgd'=>$randomizedBkgd,'align'=>$randomizedAlign);
$characterJson = json_encode($character);
$abilitiesNum = array('strength'=>$strength, 'dexterity'=>$dexterity, 'constitution'=>$constitution, 'intelligence'=>$intelligence, 'wisdom'=>$wisdom, 'charisma'=>$charisma);
$abilitiesJson = json_encode($abilitiesNum);
?>
<!--Generate button clicked.-->
<?php
    if (isset($_POST['generationBtn'])) {
        echo "<p> Race: </font>", $randomizedRace;
        echo "<br>";
        echo "<p> Class: </font>", $randomizedClass;
        echo "<br>";
        echo "<p> Background: </font>", $randomizedBkgd;
        echo "<br>";
        echo "<p> Alignment: </font>", $randomizedAlign;
        echo "<br>";
        echo "<p> - Abilities Chart - </font>";
        echo "<br>";
        echo "Strength: ", $strength;
		echo "<br>";
        echo "Dexterity: ", $dexterity;
        echo "<br>";
        echo "Constitution: ", $constitution;
        echo "<br>";
        echo "Intelligence: ", $intelligence;
        echo "<br>";
        echo "Wisdom: ", $wisdom;
        echo "<br>";
        echo "Charisma: ", $charisma;
        echo "<br><br>";
        echo "Note: You will be able to see character detail descriptions once you save your character. <br> Details like known languages are based on <b>RACE</b> and <b>BACKGROUND.</b>";
        echo "<br><br>";
    ?>
        
    <!--Saves character to database to access again-->
   	<?php echo '<p>Would you like to save your character details? If not, click the Generate button to generate a new unique character!</p>'; ?>
    <form action="db.php" method="post">
    <?php echo '<p>Enter username: </p>'; ?>
        <input type="text" style="border-radius: 3px;" name="usernameTxt" required/>
    <?php echo '<p>Enter password: </p>'; ?>
        <input type="password" style="border-radius: 3px;" name="passwordTxt" required/>
        <!--hidden, shows contents of each array-->
        <textarea hidden name="characterData"><?=$characterJson?></textarea>
        <textarea hidden name="abilitiesData"><?=$abilitiesJson?></textarea>
    <br>
    <br>
    <!--save button to save character details and adds them to database-->
    	<input type="submit" name="saveBtn" class="button" value="Save my character!" style="font-family: Times New Roman;border: 1px solid #000000;padding: 8px;border-radius: 3px;cursor: pointer;"/> </form>
    <?php
        if (isset($_POST['saveBtn'])) {
            header("Location: http://10.8.45.33/D&Dwebsite/userCharInfo.php");
        }
    }
    ?>
    <!--back button to redirect to first page-->
    <a href="http://10.8.45.33/D&Dwebsite/userStartPage.php"> <input type="button" value="Back"style="font-family: Times New Roman;border: 1px solid #000000;padding: 8px;border-radius: 3px;cursor: pointer;"/></a></p>

    <br>
    <br>
    </center>
  </body>
</html>