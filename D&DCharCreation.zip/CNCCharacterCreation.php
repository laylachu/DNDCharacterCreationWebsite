<html>
  <head>
    <title>D&D Character Generation</title>
  </head>
  <body>
  	<body style="background-color:#FFCDA2">
<center>
  <h1>Welcome to the world of D&D!</h1>
<?php
//Arrays for button choices and randomization on click
$raceArr = array("<b>Dwarf</b> <br>Stout, short and hardworking. Those might be the best words to describe a dwarf.
					<br>Having their race forged by the god Moradin, they were taught of the benefits of hard labor,
					perfection in their works, <br>and the importance of their clans. Dwarves live their long lives with a
					spirit of good and justice, <br>that may only be corrupted by greed. Their sturdiness allows
					them to be more resistant than other classes <br>in combat as well as resist poison.",
					//elf
				"<b>Elf</b> <br>Elves are magical and gracious beings, as well as very close to being eternal. They develop many different attitudes during their life. <br>When young (young being up to 100 years old) they have an adventurous and curious way of thought, making them go for adventures. By the time they <br>reach adulthood their personalities change and become much more peaceful, but don’t discard the idea of going exploring until they become elders. They make <br>for excellent artists and tend to be quite chaotic when it comes to laws. Last but not least, they don’t sleep but enter trances for 4 hours a <br>day in which they remain semiconscious.",
				"<b>Halfling</b> <br>Halflings are isolated, cheerful people who love the commodity of their homes and communities. <br>That’s the main reason most of them don’t abandon their birthplaces (shires). <br>However, a strong sense of curiosity inhabits in most of them, leading these little folk to become adventurers or travel to <br>other places. They are extremely agile, but as a result of their short legs, not as fast as the other races.", 
				"<b>Human</b> <br>Well… I suppose you are a human, so you should know what we are good at. Absolutely nothing! <br>Or more precisely, a bit in everything. Humans are quite more anxious and eager <br>to adventure than the other races due to their short lives (in comparison with the others).",
				"<b>Dragonborne</b> <br>Descendants of dragons, these draconic humanoids live in clans who they value more than their life itself. <br>Depending on their color, they get a breath attack of a specific type, as well as resistance to that <br>same type of damage in combat. They tend to be as strong as they are charismatic, <br>just like their fellow ancestors. Even though they are covered in scales, they lack the tail and wings that <br>make dragons so characteristic.",
				"<b>Gnome</b> <br>Gnomes are weird super positive beings. Their spirits shine even in the darkest nights. Great inventors, pranksters, and even better intellectuals. <br>Living away from other communities they tend to live pretty normal lives in their about 500 years. However, just like halflings, curiosity <br>is something that every one of them carries, as well as their impulsive behavior, creating excellent and many adventurers out of them.",
				"<b>Half-Elf</b> <br>These beings combine the best parts of elves and humans, or so they say. They don’t really belong in either of both worlds, <br>having to decide the community they find themselves more identified with. That’s the reason why <br>they work excellently as ambassadors or wander off feeling excluded from all places, <br>sometimes in the search for weird adventurers with whom they can find a sense of belonging.",
				"<b>Half-Orc</b> <br>Half orcs have orc blood running through their veins. This makes them much stronger than normal people, as well as hardy. <br>However, that also can make them act impulsively and savagely. They often live, or at least <br>used to in orc tribes and may or may not feel the rage of Gruumsh within them (Gruumsh being the orc god). <br>While many of them triumph as leaders in their tribe due to their high IQ in comparison with the others, others are exiled and go in <br>search of jobs in communities or go adventuring. Their high endurance makes them almost impossible to fall in combat.",
				"<b>Tiefling</b> <br>Tieflings take lots of forms and colors. They can have different kinds of horns and tails, as well as be from a great variety of colors. <br>Nevertheless, they share some kind of curse. These are beings of infernal lineage due to a pact that someone in the long past made with Asmodeus (lord of Hell). <br>They look mostly human, not taking into account the features described above. Even though they are mostly intellectual and <br>highly charismatic beings, they tend to be received with mistrust by superstitious people.");
$keyOne = array_rand($raceArr);

$classArr = array("<b>Barbarian</b> <br>A fierce warrior of primitive background who can enter a battle rage.",
 				"<b>Bard</b> <br>An inspiring magician whose power echoes the music of creation.",
 				"<b>Cleric</b> <br>A priestly champion who wields divine magic in service of a higher power.",
 				"<b>Druid</b> <br>A priest of the Old Faith, wielding the powers of nature — moonlight and plant growth, fire and lightning — and adopting animal forms.",
 				"<b>Fighter</b> <br>A master of martial combat, skilled with a variety of weapons and armor.",
 				"<b>Monk</b> <br>A master of martial arts, harnessing the power of the body in pursuit of physical and spiritual perfection.",
 				"<b>Paladin</b> <br>A holy warrior bound to a sacred oath.",
 				"<b>Ranger</b> <br>A warrior who uses martial prowess and nature magic to combat threats on the edges of civilization.",
 				"<b>Rogue</b> <br>A scoundrel who uses stealth and trickery to overcome obstacles and enemies.",
 				"<b>Sorcerer</b> <br>A spellcaster who draws on inherent magic from a gift or bloodline.",
 				"<b>Warlock</b> <br>A wielder of magic that is derived from a bargain with an extraplanar entity.",
 				"<b>Wizard</b> <br>A scholarly magic-user capable of manipulating the structures of reality.");
$keyTwo = array_rand($classArr);

$backgroundArr = array("<b>Acolyte</b>", "<b>Charlatan</b>", "<b>Criminal</b>", "<b>Entertainer</b>", "<b>Folk-Hero</b>", "<b>Guild Artisan</b>", "<b>Hermit</b>", "<b>Noble</b>", "<b>Outlander</b>", "<b>Sage</b>", "<b>Sailor</b>", "<b>Soldier</b>", "<b>Urchin</b>");
$keyThree = array_rand($backgroundArr);

$alignmentArr = array("<b>Lawful Good</b>", "<b>Neutral Good</b>", "<b>Chaotic Good</b>", "<b>Lawful Neutral</b>", "<b>True Neutral</b>", "<b>Chaotic Neutral</b>", "<b>Lawful <b>Evil</b>", "<b>Neutral Evil</b>", "<b>Chaotic Evil</b>");
$keyFour = array_rand($alignmentArr);

$abNumArr = array("15 (+2 modifier)", "14 (+2 modifier)", "13 (+1 modifier)", "12 (+1 modifier)", "10 (No modifier)", "8 (-1 modifier)");
shuffle($abNumArr);
?>
<!--Button initialization-->
    <?php echo '<p>To start, begin by generating your character by clicking the Generate button.</p>'; ?>
      <form method="post">
        <input type="submit" name="generationBtn"
                class="button" value="Generate!" />
    <br>
<!--Generate button clicked.-->
<?php
    if (isset($_POST['generationBtn'])) {
        echo "<p> <font color=#7c142c>Race: </font>", $raceArr[$keyOne];
        echo "<br>";
        echo "<p> <font color=#7c142c>Class: </font>", $classArr[$keyTwo];
        echo "<br>";
        echo "<p> <font color=#7c142c>Background: </font>", $backgroundArr[$keyThree];
        echo "<br>";
        echo "<p> <font color=#7c142c>Alignment: </font>", $alignmentArr[$keyFour];
        echo "<br>";
        echo "<p> <font color=#C70D38>- Abilities Chart - </font>";
        echo "<br>";
        echo "Strength: ", $abNumArr[0];
		echo "<br>";
        echo "Dexterity: ", $abNumArr[1];
        echo "<br>";
        echo "Constitution: ", $abNumArr[2];
        echo "<br>";
        echo "Intelligence: ", $abNumArr[3];
        echo "<br>";
        echo "Wisdom: ", $abNumArr[4];
        echo "<br>";
        echo "Charisma: ", $abNumArr[5];
        echo "<br><br>";
        echo "Note: Known languages are based on <b>RACE</b> and <b>BACKGROUND.</b>";
        echo "<br><br>";
    }
?>
    <br><br>
</center>
    </script> 
  </body>
</html>